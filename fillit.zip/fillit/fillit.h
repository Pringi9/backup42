/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fillit.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: trmoreau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/16 13:45:06 by trmoreau          #+#    #+#             */
/*   Updated: 2016/11/21 18:48:41 by trmoreau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FILLIT_H
# define FILLIT_H

/*
** Macros pour les messages d'erreur
*/

# define ERRERR	"error\n"
# define ERRARG "Error : wrong number of arguments.\nUsage : ./fillit [file]\n"
# define ERRFILE "Error : can't access the target file.\n"
# define ERRCLO "Error : can't close the target file. Oo\n"
# define ERRALOC "Error : malloc failed (returned NULL)\n"

/*
** Taille maximal du fichier avec @^ tetriminos
*/

# define BUFFSIZE 545

/*
** Lib
*/

# include <stdlib.h>
# include <sys/types.h>
# include <sys/uio.h>
# include <unistd.h>
# include <fcntl.h>
# include <unistd.h>

/*
** A VIRER
*/

# include <stdio.h>

/*
** utility.c
*/

int		ft_strlen(char *str);
void	error(char *err_msg);

/*
** pars_it.c
*/

int		count_tetri(char *str, int i, int x, int y);
char	**temp_to_final(char *temp, int tnb);
void	check_err(char **tetri);
void	pars_it(int fd, char **tetri);

/*
** do_the_truc.c
*/

void	do_the_truc(char **tetri);

#endif
