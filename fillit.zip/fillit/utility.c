/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utility.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: trmoreau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/18 14:21:05 by trmoreau          #+#    #+#             */
/*   Updated: 2016/11/18 14:27:29 by trmoreau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

int		ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i++] != '\0')
		;
	return (i);
}

void	error(char *err_msg)
{
	if (err_msg != NULL)
		write(2, err_msg, ft_strlen(err_msg));
	exit(1);
}
