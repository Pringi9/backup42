/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pars_it.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: trmoreau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/18 15:13:39 by trmoreau          #+#    #+#             */
/*   Updated: 2016/11/21 19:11:13 by trmoreau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

/*
** Fonction comtant le nobre de tetrimino et verifiant si le formatage
** du fichier est correcte.
** Oui i, x et y c'est pour la norme.
*/

int		count_tetri(char *str, int i, int x, int y)
{
	while (str[i++] != '\0')
	{
		if (++x == 4)
		{
			if (str[i] == '\n')
			{
				y++;
				i++;
			}
			else
				error(ERRERR);
			x = 0;
		}
		if (y == 4)
		{
			if (str[i] == '\n' && str[i + 1] != '\0')
				i++;
			y = 0;
		}
		if (str[i] == '\n')
			error(ERRERR);
	}
	if (x != 0 || y != 0)
		error(ERRERR);
	return (i / 21);
}

 /*
 ** Convertit le buffer du read en char **, avec 1ligne/tetriminos
 */

char	**temp_to_final(char *temp, int tnb)
{
	char	**tetri;
	int		i;
	int		i2;

	i = 0;
	i2 = 0;
	if ((tetri = malloc((tnb * sizeof(char *)) + 1)) == NULL)
		error(ERRALOC);
	tetri[tnb] = NULL;
	while (i < tnb)
		if ((tetri[i++] = malloc(17 * sizeof(char))) == NULL)
			error(ERRALOC);
	i = 0;
	tnb = 0;
	return (tetri);
}

/*
** Check la validite des tetriminos
*/

void	check_err(char **tetri)
{
}

/*
** "main" du parsing.
*/

void	pars_it(int fd, char **tetri)
{
	char	*temp;
	int		len;
	int		tnb;

	if ((temp = malloc(BUFFSIZE + 1)) == NULL)
		error(ERRALOC);
	len = read(fd, temp, BUFFSIZE + 1);
	if (len == (BUFFSIZE + 1))
		error(ERRERR);
	temp[len] = '\0';
	if ((tnb = count_tetri(temp, 0, 0, 0)) == 0)
		error(ERRERR);
	tetri = temp_to_final(temp, tnb);
	check_err(tetri);
	free(temp);
}
