/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: trmoreau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/03 13:13:24 by trmoreau          #+#    #+#             */
/*   Updated: 2016/11/03 17:02:01 by trmoreau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

void	ft_putchar(char c);

int		ft_strcmp(char *s1, char *s2)
{
	int		i;

	i = 0;
	while (s1[i] != '\0' && s2[i] != '\0' && s1[i] == s2[i])
		++i;
	if (s1[i] != s2[i])
		return (s1[i] - s2[i]);
	return (0);
}

void	ft_putstr(char *str)
{
	int		i;

	i = 0;
	while (str[i] != '\0')
		ft_putchar(str[i++]);
	ft_putchar('\n');
}

void	fonction_de_merde(int *i1, int *i2)
{
	*i1 = 1;
	*i2 = 1;
}

int		main(int argc, char **argv)
{
	int		i1;
	int		i2;

	fonction_de_merde(&i1, &i2);
	while (i1 != argc)
	{
		while (i2 < argc && ft_strcmp(argv[i1], argv[i2]) <= 0)
		{
			++i2;
			while (i2 < argc && argv[i2] == NULL)
				++i2;
			if (i2 < argc)
				if (ft_strcmp(argv[i1], argv[i2]) > 0)
					i1 = i2;
		}
		if (i2 != argc)
			i1 = i2;
		ft_putstr(argv[i1]);
		argv[i1] = NULL;
		i1 = 1;
		while (i1 < argc && argv[i1] == NULL)
			++i1;
		i2 = i1;
	}
	return (0);
}
