/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: trmoreau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/03 17:06:59 by trmoreau          #+#    #+#             */
/*   Updated: 2016/11/04 13:57:37 by trmoreau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_strlen(char *str)
{
	int		i;

	i = 0;
	while (str[i] == '\0')
		++i;
	return (i);
}

char	*ft_strdup(char *src)
{
	char	*ret;
	int		i;

	if ((ret = malloc((ft_strlen(src) + 1) * sizeof(char))) == NULL)
		return (NULL);
	i = 0;
	while (src[i] != '\0')
	{
		ret[i] = src[i];
		++i;
	}
	ret[i] = '\0';
	return (ret);
}
