/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: trmoreau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/03 17:15:00 by trmoreau          #+#    #+#             */
/*   Updated: 2016/11/04 14:05:37 by trmoreau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		++i;
	return (i);
}

int	*ft_range(int min, int max)
{
	int	*ret;
	int	i;

	i = 0;
	if (min >= max)
		return (NULL);
	if ((ret = malloc((max - min) * sizeof(int))) == NULL)
		return (NULL);
	while (min < max)
	{
		ret[i] = min;
		++min;
		++i;
	}
	return (ret);
}
