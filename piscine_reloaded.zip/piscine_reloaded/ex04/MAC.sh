ifconfig | grep "..:..:..:..:..:.." | cut -d ' ' -f 2- | rev | cut -c 2- | rev
