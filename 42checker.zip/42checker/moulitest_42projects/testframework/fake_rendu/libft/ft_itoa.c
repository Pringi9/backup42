#include <libft.h>
char		*ft_itoa(int n)
{
	(void)n;
	return (ft_strdup(""));
}
