#include <libft.h>
void	ft_putendl(char const *s)
{
	(void)s;
	write(1, "123", 1);
}
