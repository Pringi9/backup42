#include <libft.h>
int		ft_isupper(int c)
{
	return (c);
}
