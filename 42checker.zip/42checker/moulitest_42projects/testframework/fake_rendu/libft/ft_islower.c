#include <libft.h>
int		ft_islower(int c)
{
	(void)c;
	return (0);
}
