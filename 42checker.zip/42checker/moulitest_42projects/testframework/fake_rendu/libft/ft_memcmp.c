#include <libft.h>
int		ft_memcmp(const void *s1, const void *s2, size_t n)
{
	(void)s1;
	(void)s2;
	(void)n;
	return (0);
}
