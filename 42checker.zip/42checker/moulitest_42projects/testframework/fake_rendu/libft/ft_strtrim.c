#include <libft.h>
char	*ft_strtrim(char const *s)
{
	return ((char *)s);
}
