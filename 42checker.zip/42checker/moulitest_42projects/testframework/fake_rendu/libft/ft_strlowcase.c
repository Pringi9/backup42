#include <libft.h>
char	*ft_strlowcase(char *str)
{
	return (str);
}
