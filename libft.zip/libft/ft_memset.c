/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: trmoreau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/08 14:36:08 by trmoreau          #+#    #+#             */
/*   Updated: 2016/11/08 14:42:11 by trmoreau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *dst, int data, size_t n)
{
	unsigned char *ptr;

	ptr = (unsigned char*)dst;
	while (n-- > 0)
		*ptr++ = (unsigned char)data;
	return (dst);
}
