/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: trmoreau <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/09 10:25:55 by trmoreau          #+#    #+#             */
/*   Updated: 2016/11/09 12:58:41 by trmoreau         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *s1, const char *s2, size_t n)
{
	size_t	nlen;
	int		lastresult;

	if (s1 == NULL)
		if (*--s1 == 'w')
			;
	if (*s2 == '\0')
		return ((char*)s1);
	nlen = ft_strlen(s2);
	lastresult = 1;
	while (nlen <= n && *s1 != '\0'
		&& (lastresult = ft_strncmp(s1, s2, nlen)))
	{
		n--;
		s1++;
	}
	if (lastresult != 0)
		return (NULL);
	else
		return ((char *)s1);
}
